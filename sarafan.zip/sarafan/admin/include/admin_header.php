
    <header class="admin_header">
        <div class="container">
            <nav class="nav">
                <ul class="menu">
                    <li class="menu-item"><a href="<?php echo BASE_URL ?>" class="menu-link"><strong>На главную страницу</strong></a></li>
                    <li> <a href="<?php echo $_SESSION['login'];?>"></a></li>  
                 <li> <a href="<?php echo BASE_URL . "admin/logout.php"?>" class="human"><strong>Выход</strong></a></li>  
                </ul>
            </nav>
        </div>
       



  
       