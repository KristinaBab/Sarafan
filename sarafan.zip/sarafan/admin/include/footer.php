

 <!-- футер  -->
 <div class="footer">
            <div class="div container">
                <div class="footer__wrapper">
                   <div class="footer__block">
                    <a  href="#">
                        <img class="footer__logo" src="<?php echo BASE_URL . "img/logo.png"?>" alt="">
                    </a>
                   </div>
                   <div class="footer__block">
                    <nav class="nav nav__footer">
                            <h3  class="mini__title">Помощь</h3>

                            <a  class="navLink" href="#">Оплата</a>
                            <a  class="navLink" href="#">Доставка</a>
                            <a  class="navLink" href="#">Возврат и обмен</a>
                    </nav>
                   </div>
                   <div class="footer__block">
                    <nav class="nav nav__footer">
                        <h3  class="mini__title">Компания</h3>

                        <a  class="navLink" href="#">О нас</a>
                        <a  class="navLink" href="#">Наши магазины</a>
                        <a  class="navLink" href="#">Контакты</a>
                    </nav>
                   </div>
                   <div class="footer__block">
                    <nav class="nav nav__footer">
                        <h3  class="mini__title">Следите за нами</h3>

                        <a  class="navLink" href="#">TikTok</a>
                        <a  class="navLink" href="#">Vk</a>
                        <a  class="navLink" href="#">Telegram</a>
                        <a  class="navLink" href="#">Pinterest</a>
                    </nav>
                   </div>
                </div>
                <div class="label">
                    <p class="element">
                      Все права защищены.Пользовательское соглашение.Политика конфиденциальности<br />© 2022 sarafancollection.ru
                    </p>
                  </div>  
                  
            </div>
        </div>

 <!-- /футер -->
