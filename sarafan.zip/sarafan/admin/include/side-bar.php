<? include '../../path.php'?>
<div class="row">
                <div class="sidebar col-3">
                    <ul>
                        <li>
                            <a href="<?= BASE_URL . "admin/admin_panel/posts/index.php" ?>">Записи</a>
                        </li>
                        <li>
                            <a href="<?= BASE_URL . "admin/admin_panel/users/index.php" ?>">Пользователи</a>
                        </li>
                        <li>
                            <a href="<?= BASE_URL . "admin/admin_panel/topics/index.php" ?>">Категории</a>
                        </li>
                    </ul>
                </div>