function openNavCart() {
    document.getElementById("mySidenavCart").style.width = "600px";
}

function closeNavCart() {
    document.getElementById("mySidenavCart").style.width = "0";
}

const productsBtn = document.querySelectorAll('.btn-product-page')
const cartProductList = document.querySelector('.cart-content__list');
const cart= document.querySelector('.cart');
const cartQuantity= document.querySelector('.cart__quantity');
const fullPrice= document.querySelector('.fullprice');

let price= 0;

const randomId = () => {
	return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

// const priceWithoutSpaces = (str) => {
// 	return str.replace(/\s/g, '');
// };

const normalPrice = (str) => {
	return String(str).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
};

const plusFullPrice = (currentPrice)=>{
    return price += currentPrice;
};

const minusFullPrice = (currentPrice)=>{
    return price -= currentPrice;
};

const printFullPrice = ()=>{
    fullPrice.textContent= `${normalPrice(price)} руб`;
};

const printQuantity = () => {
	let productsListLength = cartProductsList.querySelector('.simplebar-content').children.length;
	cartQuantity.textContent = productsListLength;
	productsListLength > 0 ? cart.classList.add('active') : cart.classList.remove('active');
};




const generateCartProduct = (img, title, price, color, size , id) =>{
    return `
    <li class="cart-content__item">
    <article class="cart-content__product cart-product" data-id="${id}">
       
        <img src="${img}" alt="dress" class="cart-product__img">
           
        <div class="cart-product__text">
              
               <h3 class="cart-product__title">${title}</h3>
               <span class="cart-product__price">${price}</span>
                
               <div class="cart__size">
                   <h4 class="cart-product__size">Размер</h4>
                   <select class="box__cart">
                       <optionvalue="default" >${size}</option>
                       <option value="S">S</option>
                       <option value="m">M</option>
                       <option value="l">L</option>
                       <option value="xl">XL</option>
                     </select>
               </div>
               <div class="cart-product__color">
               <h4 class="cart-product__color__color">Цвет</h4>
                   <p class="cart-product__color__name">${color}</p>
               </div>

               <div class="cart-product__delete">
                  <div class="cart-product__delete__img"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                       <g clip-path="url(#clip0_1_1012)">
                       <path d="M12.0622 15.1112H3.93775C3.76673 15.1072 3.59817 15.0695 3.44172 15.0003C3.28527 14.9311 3.14398 14.8317 3.02594 14.7079C2.9079 14.5841 2.81541 14.4382 2.75376 14.2786C2.69211 14.1191 2.66251 13.9489 2.66664 13.7779V4.99121H3.55553V13.7779C3.55129 13.8322 3.55782 13.8868 3.57476 13.9386C3.5917 13.9904 3.6187 14.0383 3.65422 14.0796C3.68974 14.1209 3.73308 14.1548 3.78174 14.1793C3.8304 14.2037 3.88342 14.2184 3.93775 14.2223H12.0622C12.1165 14.2184 12.1695 14.2037 12.2182 14.1793C12.2669 14.1548 12.3102 14.1209 12.3457 14.0796C12.3812 14.0383 12.4082 13.9904 12.4252 13.9386C12.4421 13.8868 12.4487 13.8322 12.4444 13.7779V4.99121H13.3333V13.7779C13.3374 13.9489 13.3078 14.1191 13.2462 14.2786C13.1845 14.4382 13.092 14.5841 12.974 14.7079C12.856 14.8317 12.7147 14.9311 12.5582 15.0003C12.4018 15.0695 12.2332 15.1072 12.0622 15.1112Z" fill="#6F6F6F"/>
                       <path d="M13.68 3.99997H2.22222C2.10434 3.99997 1.9913 3.95315 1.90795 3.8698C1.8246 3.78645 1.77777 3.6734 1.77777 3.55553C1.77777 3.43765 1.8246 3.32461 1.90795 3.24126C1.9913 3.15791 2.10434 3.11108 2.22222 3.11108H13.68C13.7979 3.11108 13.9109 3.15791 13.9943 3.24126C14.0776 3.32461 14.1244 3.43765 14.1244 3.55553C14.1244 3.6734 14.0776 3.78645 13.9943 3.8698C13.9109 3.95315 13.7979 3.99997 13.68 3.99997Z" fill="#6F6F6F"/>
                       <path d="M9.33331 5.77783H10.2222V12.4445H9.33331V5.77783Z" fill="#6F6F6F"/>
                       <path d="M5.77777 5.77783H6.66666V12.4445H5.77777V5.77783Z" fill="#6F6F6F"/>
                       <path d="M10.2222 2.60447H9.37777V1.7778H6.62222V2.60447H5.77777V1.7778C5.77749 1.54956 5.86501 1.32995 6.02222 1.16447C6.17942 0.998993 6.39426 0.900328 6.62222 0.888916H9.37777C9.60573 0.900328 9.82057 0.998993 9.97777 1.16447C10.135 1.32995 10.2225 1.54956 10.2222 1.7778V2.60447Z" fill="#6F6F6F"/>
                       </g>
                       <defs>
                       <clipPath id="clip0_1_1012">
                           <rect width="16" height="16" fill="white"/>
                       </clipPath>
                       </defs>
                   </svg> <span class="cart-product__delete__text">Удалить</span> </div>

               </div>
         </div>
</article>
</li>
    
    `;
}

const deleteProducts = (productParent)=>{

    let id = productParent.querySelector('.cart-product').dataset.id;

    document.querySelector(`.cart-content__product[data-id="${id}"]`).querySelector('.product__btn').disabled = false;
  
    let currentPrice = parseInt(parent.querySelector('.cart-product__price '));
    minusFullPrice(currentPrice);
    printFullPrice();
    productParent.remove();
    printQuantity();
};

productsBtn.forEach(el => {
    el.closest('.cart-content__product').setAttribute('data-id', randomId());

    el.addEventListener('click' , (e) => {
        let self =e.currentTarget;
        let parent =self.closest('.cart-content__product');
        let id = parent.dataset.id;
        let img = parent.querySelector('.swiper-slide').getAttribute('src');
        let title = parent.querySelector('.products__title');
        // let priceString = parent.querySelector('.price__current ');
        let priceNumber =parseInt(parent.querySelector('.product-price__current '));
        
        plusFullPrice(priceNumber);

        console.log(price);

        printFullPrice();

        cartProductList.querySelector('.simplebar-content').insertAdjacentHTML('afterbegin', generateCartProduct(img , title, priceNumber, color, size,id) );

        printQuantity();

        self.disable = true; 

    });
});

cartProductList.addEventListener('click', (e) =>{
    if(e.target.classList.contains('cart-product__delete')){
        deleteProducts(e.target.closest('.cart-content__item'));
    };
})