function openNav() {
    document.getElementById("mySidenav").style.width = "600px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

