<?php 
const SITE_ROOT = __DIR__;
const BASE_URL = "http://kristiuo.beget.tech/";
define("ROOT_PATH", realpath(dirname(__FILE__)));

?>